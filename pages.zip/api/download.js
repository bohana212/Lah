import { createClient } from '@supabase/supabase-js';
import ytdl from 'ytdl-core';  // For YouTube
import ytdlp from 'yt-dlp';  // For Instagram, TikTok, etc.
import fetch from 'node-fetch';

const supabase = createClient(
  process.env.SUPABASE_URL, 
  process.env.SUPABASE_ANON_KEY 
);

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { link, type } = req.body; 

    if (!link) {
      return res.status(400).json({ error: 'Link tidak valid' });
    }

    try {
      let downloadUrl = '';
      let fileType = 'mp4';
      let platform = '';

      if (ytdl.validateURL(link)) {
        platform = 'YouTube';
        const info = await ytdl.getInfo(link);
        const format = type === 'mp3'
          ? ytdl.chooseFormat(info.formats, { quality: 'highestaudio' })
          : ytdl.chooseFormat(info.formats, { quality: 'highestvideo' });
        
        downloadUrl = format.url;
      } else if (link.includes('instagram.com') || link.includes('tiktok.com')) {
        platform = 'Instagram/TikTok';
        const video = await ytdlp.getInfo(link);
        downloadUrl = video.formats.find(f => f.quality === 'high').url;
        fileType = 'mp4'; 
      } else {
        return res.status(400).json({ error: 'Platform tidak didukung' });
      }

      const { data, error } = await supabase
        .from('downloads')
        .insert([
          {
            link,
            platform,
            type,
            download_url: downloadUrl
          }
        ]);

      if (error) {
        return res.status(500).json({ error: 'Terjadi kesalahan saat menyimpan data ke Supabase' });
      }

      res.status(200).json({
        status: 'success',
        message: 'Download siap!',
        download_url: downloadUrl,
        file_type: fileType
      });

    } catch (error) {
      res.status(500).json({ error: 'Gagal memproses link: ' + error.message });
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}
